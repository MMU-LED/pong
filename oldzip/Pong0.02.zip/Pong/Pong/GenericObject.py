class Object(object):
    """description of class"""
    #parent class for paddle and ball - atm sets scale, height, width variables and 'freeze' method


    scale = 10
    height = 90 * scale
    width = 80 * scale

    def freeze(): #for when game freezes, e.g on player score or new game
        dx = 0;
        dy = 0; 




        
        



