import pygame
import GenericObject

class Ball(GenericObject):
    """"""

    x
    y
    ballRadiusX = 5*scale
    ballRadiusY = ballRadiusX 
    topOfBall = y + ballRadiusY
    botOfBall = y - ballRadiusY
    rightOfBall = x + ballRadiusX
    leftOfBall = x - ballRadiusX
    s #speed :) 
    dx = s * scale
    dy = s * scale

    
    def __init__ (self, x, y, s): #initiate class (constructor?)
        self.x = x
        self.y = y 
        self.s = s

    def render(): #this needs finishing i think - lookup pygame.draw commands 
        pygame.draw.ellipse()

    def reset(): #reset ball position to centre of screen - needs changing so resets to near paddle - also needs dx dy values setting
        x = 0 + 1/2 * width
        y = 0 + 1/2 * height 

    def move(): #self explanatory
        x = x + dx
        y = y + dxy
        

    def score(): #if ball exceeds left side of screen, score right = true, if ball exceeds right side, score left = true
        if x + ballRadiusX > width:
            scoreLeft = True
            scoreRight = False
            reset()
        if x - ballRadiusX < 0:
            scoreRight = True
            scoreLeft = False
            reset()


    def edgeDetect ():
        if y + ballRadiusY > height or y - ballRadiusY < 0: 
            dy = - dy 
            
    def bounce(self, Paddle): #self is like 'this' in java 
        #ball reflects off paddle - atm ball going horizontally 
        #this needs changing so the ball comes off at an angle depending on where the ball contacts the paddle
        #along the y axis 
        if self.topOfBall > Paddle.top and self.botOfBall < Paddle.bottom:
            if self.rightOfBall == Paddle.x or self.leftOfBall == Paddle.x:
                dx = - dx 
                dy = - dy
            
      

        

