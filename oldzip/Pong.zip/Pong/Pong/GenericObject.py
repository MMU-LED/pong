class Object(object):
    """description of class"""
    

    x
    y
    dx
    dy
    scale = 10
    height = 90 * scale
    width = 80 * scale

    def freeze():
        dx = 0;
        dy = 0; 




        
        



