class Ball(object):
    """"""

    x
    y
    ballWidth = 5*scale
    ballLength = 5*scale 
    dx 
    dy

    def move(): #self explanatory
        x = x + dx
        y = y + dx

    def reflect(): 
        #ball reflects off paddle - atm ball going vertically
        #this needs changing so the ball comes off at an angle depending on where the ball contacts the paddle
        #along the y axis 
        dx = - dx
        dy = - dy

    def score(): #if ball exceeds left side of screen, score right = true, if ball exceeds right side, score left = true
        if x + ballwidth > 80:
            scoreLeft = True
        if x - ballwidth < 0:
            scoreRight = True


    def 









